package com.brieguttuso.firstproject;

public class purchasedFood implements describeable {

    private String name;
    private double cost;

    public purchasedFood(String name, double cost) {
        this.name = name;
        this.cost = cost;
    }

    public String getName() {
        return name;
    }

    public double getCost() {
        return cost;
    }

    public String getDescription(){

        return name;
    }
}
