package com.brieguttuso.firstproject;

public class mainCourse extends recipe {

    private int points;

    public mainCourse(String name, String[] ingredients, String instructions, int points) {
        super(name, ingredients, instructions);
        this.points = points;
    }

    public String getDescription() {

        return "The entree " + getName() + " has " + points + " points.";

    }
}
