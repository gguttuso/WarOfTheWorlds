package com.brieguttuso.firstproject;

public class dessert extends recipe {

    private int calories;

    public dessert(String name, String[] ingredients, String instructions, int calories) {
        super(name, ingredients, instructions);
        this.calories = calories;
    }

    public int getCalories() {
        return calories;
    }

    public String getDescription(){

        return "The dessert " + getName() + " has " + calories + " calories.";

    }
}
