package com.brieguttuso.firstproject;

// created interface so that purchasedFoods can be added to the arrayList under recipe (currently not related to receipe)
// we changed the receipe arrayList to describable arrayList so they can both getDescription
public interface describeable {

    public String getDescription();
}
