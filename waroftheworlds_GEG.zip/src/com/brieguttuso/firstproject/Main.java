package com.brieguttuso.firstproject;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        // create an array list of recipe
        // we changed this to an arrayList of "describeable"
        ArrayList<describeable> menu = new ArrayList<>();

        // add pizza to main course
        // pass in name(string), ingredients(string array), instructions(string) and points(int)
        menu.add(new mainCourse("Pizza", new String[]{"Crust", "Sauce", "Cheese"},
                "Put together and bake", 34));

        // add ice cream to dessert
        // pass in name(string), ingredients(string array), instructions(string) and calories(int)
        menu.add(new dessert("Ice cream", new String[]{"Milk", "Sugar", "Rum"},
                "Mix and chill", 456));

        menu.add(new purchasedFood("italian bread", 1.25));

        for(describeable item:menu){

            System.out.println(item.getDescription());

        }
    }
}
